/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author u10047649100
 */
// classe tem metodo e atributos
// herdou da classe pessoa, e herda os metodos e atributos
public class Medico extends Pessoa {
    
    //override  refaz metodo que ja existe
       @Override
       public void aniversario(){
           
       }
    public static void main(String[] args) { 
        Medico medico = new Medico();                
        medico.aniversario();
        
    }
}
